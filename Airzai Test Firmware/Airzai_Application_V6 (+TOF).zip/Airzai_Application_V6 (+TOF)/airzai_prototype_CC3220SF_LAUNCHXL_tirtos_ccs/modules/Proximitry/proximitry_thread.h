#ifndef PROXIMITRY_THREAD_H
#define PROXIMITRY_THREAD_H

#include <pthread.h>

void * VL53L0X_Task(void *pvParameters);

#endif
