#ifndef _PWM_API_
#define _PWM_API_

void api_pwm_init(void);
void api_pwm0_enable(void);
void api_pwm1_enable(void);
void api_pwm0_disable(void);
void api_pwm1_disable(void);

#endif
